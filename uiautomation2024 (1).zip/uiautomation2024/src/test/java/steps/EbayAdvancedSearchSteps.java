package steps;

import java.time.Duration;

import static org.junit.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EbayAdvancedSearchSteps {

    private WebDriver driver;
    private WebDriverWait wait;

    @Before
    public void setUp() {
        // Set up the ChromeDriver and WebDriverWait
        System.setProperty("webdriver.chrome.driver", "webdrivers/chromedriver.exe"); // Update path as needed
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Wait for 10 seconds
    }

    @Given("I am on Ebay Advanced Search Page")
    public void i_am_on_ebay_advanced_search_page() {
        driver.get("https://www.ebay.com/sch/ebayadvsearch"); // Ebay Advanced Search URL
    }

    @When("I click on Ebay Logo")
    public void i_click_on_ebay_logo() {
        WebElement ebayLogo = wait.until(ExpectedConditions.elementToBeClickable(By.id("gh-logo")));
        ebayLogo.click();
    }

    @Then("I am navigated to Ebay Home Page")
    public void i_am_navigated_to_ebay_home_page() {
        // Wait for the page to load and verify that we are on the homepage
        wait.until(ExpectedConditions.urlToBe("https://www.ebay.com/"));
        assertTrue("User is not on the Ebay home page", driver.getCurrentUrl().equals("https://www.ebay.com/"));
    }

    @After
    public void tearDown() {
        // Close the browser after the test
        if (driver != null) {
            driver.quit();
        }
    }
}
