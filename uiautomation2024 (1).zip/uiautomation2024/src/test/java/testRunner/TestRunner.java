package testRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class) // Tells JUnit to run Cucumber tests
@CucumberOptions(features = "src/test/features/EbayAdvancedSearch.feature", // Pointing directly to your feature file
                glue = "steps", // The package where your step definition classes are located
                plugin = {
                                "pretty", // Provides readable console output
                                "html:target/cucumber-reports.html", // Generates an HTML report in the target folder
                                "json:target/cucumber.json" // Generates a JSON report
                }, tags = "@P3" // Filters tests to only run scenarios tagged with @P3 (modify as needed)
)
public class TestRunner {
        // This class is empty, as the @RunWith annotation will automatically run the
        // tests
}
