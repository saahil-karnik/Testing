Step 1: Download proper chromedriver compatible with your version of Chrome from the following URL: ChromeDriver https://googlechromelabs.github.io/chrome-for-testing/#stable. To check version of chrome.Open Google Chrome.Go to the menu: Click the three dots in the top-right corner.Click on "Help" > "About Google Chrome."The version of Chrome will be displayed in the format: Google Chrome XX.X.XXX.X.
Step 2: open the Folder Project
Step 3: Run this project oin the terminal. Start terminal and type command mvn test or mvn clean install
